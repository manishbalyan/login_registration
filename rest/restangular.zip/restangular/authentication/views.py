from django.shortcuts import render
from models import  User
from rest_framework import viewsets
from rest_framework.response import Response
from serializers import UserSerializer
from django.contrib.auth import authenticate, login
from rest_framework import status
from rest_framework.decorators import api_view
from django.http import HttpResponse
import json
# Create your views here.


@api_view(['GET', 'POST'])
def UserViewSet(request, format=None):
    """
        List all user, or create a new user.
    """
    if request.method == 'GET':
        users = User.objects.all()
        serializer = UserSerializer(users, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'POST'])
def LoginViewSet(request, format=None):
    print "HI"
    if request.method == 'POST':
        data = UserSerializer(data=request.data)

        email = data.get('email', None)
        password = data.get('password', None)

        user = authenticate(email=email, password=password)

        if user is not None:
            if user.is_active:
                login(request, user)

                serialized = UserSerializer(user)

                return Response(serialized.data)
            else:
                return Response({
                    'status': 'Unauthorized',
                    'message': 'This account has been disabled.'
                }, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response({
                'status': 'Unauthorized',
                'message': 'Username/password combination invalid.'
            }, status=status.HTTP_401_UNAUTHORIZED)

